timer.Create("HunterAngry", 0, 0, function() HUNTER_CHECK(nil) end )
function HUNTER_CHECK()
for k, hunter in pairs( ents.FindByClass( "npc_hunter" ) ) do
	if hunter:Health() <= 63 then
	 hunter:SetSkin(1);
	 else hunter:SetSkin(0);
		end
	end
end