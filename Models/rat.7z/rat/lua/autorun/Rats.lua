local Category = "Animals"
local NPC = { Name = "Rat", Class = "monster_generic", Model = "models/unusedrat.mdl", Category = Category	} list.Set( "NPC", "npc_leakrat", NPC )
local NPC = { Name = "Rat (Mega Build)", Class = "monster_generic", Model = "models/ratleaknet.mdl", Category = Category	} list.Set( "NPC", "npc_megabuildrat", NPC )
local NPC = { Name = "Rat (Textureless)", Class = "monster_generic", Model = "models/rat_textureless.mdl", Category = Category	} list.Set( "NPC", "npc_leakrattextureless", NPC )