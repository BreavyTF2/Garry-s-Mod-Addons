local Category = "Zombies + Enemy Aliens"

local NPC = { Name = "Zombie Assassin", Class = "npc_fastzombie", KeyValues = { SquadName = "zombies" }, Model = "models/zafast.mdl", Category = Category } list.Set( "NPC", "npc_fast_zombie_assassin", NPC )