-- Missile Defense file, by Ry13y04 and Breavy

local function AddNPC( t, class )
	list.Set( "NPC", class or t.Class, t )
end

local Category = "Combine" 
	AddNPC( { Name = "Missile Defense", Class = "npc_missiledefense",  KeyValues = { SquadName = "overwatch" }, Category = Category} )