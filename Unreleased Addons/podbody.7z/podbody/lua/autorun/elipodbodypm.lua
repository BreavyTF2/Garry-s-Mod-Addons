AddCSLuaFile()

player_manager.AddValidModel("Eli (Podbody)", "models/alieneer/eli_podbody_player.mdl" )
player_manager.AddValidHands( "Eli (Podbody)", "models/weapons/c_arms_citizen.mdl", 1, "0000000" )
list.Set( "PlayerOptionsAnimations", "Eli (Podbody)", { "menu_walk" } )