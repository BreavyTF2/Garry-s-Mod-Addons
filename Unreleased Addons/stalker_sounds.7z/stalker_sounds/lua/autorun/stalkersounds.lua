sound.Add( {
	name = "NPC_Stalker.Die",
	channel = CHAN_BODY,
	volume = VOL_NORM,
	level = "SNDLVL_NORM",
	pitch = "PITCH_NORM",
	sound = "npc/stalker/die1.wav", "npc/stalker/die2.wav", "npc/stalker/die3.wav"

} )
sound.Add( {
	name = "NPC_Stalker.Ambient01",
	channel = CHAN_BODY,
	volume = VOL_NORM,
	level = "SNDLVL_NORM",
	pitch = "PITCH_NORM",
	sound = "npc/stalker/breathing3.wav"

} )
sound.Add( {
	name = "NPC_Stalker.Pain",
	channel = CHAN_BODY,
	volume = VOL_NORM,
	level = "SNDLVL_NORM",
	pitch = "PITCH_NORM",
	sound = "npc/stalker/pain1.wav", "npc/stalker/pain2.wav", "npc/stalker/pain3.wav", "npc/stalker/pain4.wav"

} )
sound.Add( {
	name = "NPC_Stalker.Screan",
	channel = CHAN_BODY,
	volume = VOL_NORM,
	level = "SNDLVL_NORM",
	pitch = "PITCH_NORM",
	sound = "npc/stalker/go_alert1.wav", "npc/stalker/go_alert2.wav", "npc/stalker/go_alert3.wav"

} )