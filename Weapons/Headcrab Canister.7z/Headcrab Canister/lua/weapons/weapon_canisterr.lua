if (SERVER) then
    AddCSLuaFile( "weapon_canisterr.lua" )
    SWEP.Weight= 5
    SWEP.AutoSwitchTo= false
    SWEP.AutoSwitchFrom= false
end

if ( CLIENT ) then
    SWEP.PrintName            = "Regular Headcrab Canister Launcher" 
    SWEP.Slot                = 3
    SWEP.SlotPos            = 1
    SWEP.DrawAmmo= false
    SWEP.DrawCrosshair= true
end

SWEP.Author            = "Jimbomcb, Edited by Alieneer"
SWEP.Contact= ""
SWEP.Purpose         = ""
SWEP.Instructions    = "Left click to launch a regular headcrab canister at your target.\nRight click to spawn a pre-impacted canister.\n\nRequires a path to the sky."
SWEP.Category = "Headcrab Canisters"

SWEP.Spawnable= true
SWEP.AdminSpawnable= trueo

SWEP.ViewModel            = "models/weapons/c_357.mdl"
SWEP.WorldModel            = "models/weapons/w_357.mdl"
SWEP.ViewModelFlip        = false
SWEP.ViewModelFOV       = GetConVarNumber("viewmodel_fov")
SWEP.UseHands	= true

SWEP.Primary.ClipSize      = -1
SWEP.Primary.DefaultClip   = -1
SWEP.Primary.Automatic     = false
SWEP.Primary.Ammo          = "none"
SWEP.Secondary.ClipSize    = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic   = false
SWEP.Secondary.Ammo        = "none"

local ShootSoundFire = Sound( "Airboat.FireGunHeavy" )
local ShootSoundFail = Sound( "WallHealth.Deny" )
local YawIncrement = 20
local PitchIncrement = 10

if CLIENT then
    language.Add ("Undone_CrabLaunch", "Undone Regular Headcrab Canister")
end
 

function SWEP:PrimaryAttack(bSecondary)
    local tr = self.Owner:GetEyeTrace()
    self:ShootEffects(self)
    
    if (SERVER) then 
        local aBaseAngle = tr.HitNormal:Angle()
        local aBasePos = tr.HitPos
        local bScanning = true
        local iPitch = 10
        local iYaw = -180
        local iLoopLimit = 0
        local iProcessedTotal = 0
        local tValidHits = {} 

        while (bScanning == true && iLoopLimit < 500) do
            iYaw = iYaw + YawIncrement
            iProcessedTotal = iProcessedTotal + 1        
            if (iYaw >= 180) then
                iYaw = -180
                iPitch = iPitch - PitchIncrement
            end
            
            local tLoop = util.QuickTrace( aBasePos, (aBaseAngle+Angle(iPitch,iYaw,0)):Forward()*40000 )
            if (tLoop.HitSky || bSecondary) then 
                table.insert(tValidHits,tLoop) 
            end
                
            if (iPitch <= -80) then
                bScanning = false
            end
            iLoopLimit = iLoopLimit + 1
        end
        
        local iHits = table.Count(tValidHits)
        if (iHits > 0) then
            local iRand = math.random(1,iHits) 
            local tRand = tValidHits[iRand]        
            
            local ent = ents.Create( "env_headcrabcanister" )
            ent:SetPos( aBasePos )
            ent:SetAngles( (tRand.HitPos-tRand.StartPos):Angle() )
            ent:SetKeyValue( "HeadcrabType", math.random(0,2) )
            ent:SetKeyValue( "HeadcrabCount", math.random(2,5) )
            ent:SetKeyValue( "FlightSpeed", math.random(2500,6000) )
            ent:SetKeyValue( "FlightTime", math.random(2,5) )
            ent:SetKeyValue( "Damage", math.random(50,90) )
            ent:SetKeyValue( "DamageRadius", math.random(300,512) )
            ent:SetKeyValue( "SmokeLifetime", math.random(5,10) )
            ent:SetKeyValue( "StartingHeight",  1000 )
            local iSpawnFlags = 8192
            if (bSecondary) then iSpawnFlags = iSpawnFlags + 4096 end //If Secondary, spawn impacted.
            ent:SetKeyValue( "spawnflags", iSpawnFlags )
            
            ent:Spawn()
            	ent:Activate()
	
            ent:Input("FireCanister", self.Owner, self.Owner)

            undo.Create("CrabLaunch")
                undo.AddEntity( ent )
                undo.SetPlayer( self.Owner )
                undo.AddFunction(function(undo)
                    for k, v in pairs(ents.FindByClass("npc_headcrab*"))do 
                        if (v:GetOwner() == ent) then v:Remove() end
                    end
                end)
            undo.Finish()
            self:EmitSound( ShootSoundFire )
        else
            self:EmitSound( ShootSoundFail )
        end
end
        tLoop = nil
        tValidHits = nil
    end


function SWEP:SecondaryAttack() self:PrimaryAttack(true) end

function SWEP:ShouldDropOnDie()
    return false
end
