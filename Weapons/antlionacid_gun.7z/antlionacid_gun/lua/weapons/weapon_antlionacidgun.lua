if ( !IsMounted( "ep2" ) ) then return end

AddCSLuaFile()

sound.Add( {
	name = "AntlionAcid",
	channel = CHAN_WEAPON,
	volume = 0.8,
	level = 90,
	pitch = { 95, 105 },
	sound = "npc/antlion/antlion_shoot1.wav"
} )

game.AddParticles( "particles/antlion_worker.pcf" )
	
game.AddParticles( "particles/antlion_gib_02.pcf" )
	
PrecacheParticleSystem( "antlion_spit" )
	
PrecacheParticleSystem( "antlion_spit_trail" )
	
PrecacheParticleSystem( "blood_impact_yellow_01" )

SWEP.PrintName = "Antlion Acid Gun"
SWEP.Author = "Alieneer"
SWEP.Purpose = "Fires Antlion Acid as a weapon."

SWEP.Slot = 4
SWEP.SlotPos = 2

SWEP.Spawnable = true

SWEP.ViewModel = Model( "models/weapons/c_rpg.mdl" )
SWEP.WorldModel = Model( "models/weapons/w_rocket_launcher.mdl" )
SWEP.ViewModelFOV = GetConVar( "viewmodel_fov" )
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawAmmo = false
SWEP.AdminOnly = true


local ShootSound = Sound( "AntlionAcid" )

function SWEP:Initialize()

	self:SetHoldType( "rpg" )

end

function SWEP:Reload()
end

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire( CurTime() + 2 )
	self:EmitSound( ShootSound )
	self:ShootEffects( self )
	if ( !SERVER ) then return end
	local eAng = self.Owner:EyeAngles()
	local Forward = self.Owner:EyeAngles():Forward()
	local shootPos = self.Owner:GetShootPos() + eAng:Forward() * 15 + eAng:Right()*15 - eAng:Up() * -4
	local SpitTypes = {
            "models/spitball_large.mdl",
            "models/spitball_medium.mdl",
            "models/spitball_small.mdl"
    }
	for i=6,8 do
	local ent = ents.Create( "grenade_spit" )
	if ( IsValid( ent ) ) then
	ent:SetPos(shootPos + Vector(math.Rand(10,-10),math.Rand(10,-10),math.Rand(10,-10)))
	ent:SetAngles( self.Owner:EyeAngles() )
	ent:SetModel(table.Random(SpitTypes))
	ent:Spawn()
	ent:SetOwner(self.Owner)
	ent:SetVelocity( Forward * 1500 + Vector(0,0,15))
	ent:SetModel(table.Random(SpitTypes))
		end
	end
end