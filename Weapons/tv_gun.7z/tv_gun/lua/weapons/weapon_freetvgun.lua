AddCSLuaFile()

sound.Add( {
	name = "FreeTVShootSingle",
	channel = CHAN_WEAPON,
	volume = 1.0,
	level = "140",
	pitch = { 95, 105 },
	sound = "weapons/smg1/smg1_fire2.wav"
} )

SWEP.PrintName = "Free TV Gun"
SWEP.Author = "Motosman"
SWEP.Purpose = "Shoot TVs with primary attack."

SWEP.Slot = 3
SWEP.SlotPos = 2

SWEP.Spawnable = true

SWEP.ViewModel = Model( "models/weapons/c_leak_hkmp5k.mdl" )
SWEP.WorldModel = Model( "models/weapons/w_leak_hkmp5k.mdl" )
SWEP.ViewModelFOV = GetConVar( "viewmodel_fov" )
SWEP.UseHands = true

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = true
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.DrawAmmo = false
SWEP.AdminOnly = true

local ShootSound = Sound( "FreeTVShootSingle" )

function SWEP:Initialize()

	self:SetHoldType( "smg" )

end

function SWEP:Reload()
end

function SWEP:CanBePickedUpByNPCs()
	return true
end

function SWEP:PrimaryAttack()

	self:SetNextPrimaryFire( CurTime() + 0.1 )
 
	self:EmitSound( ShootSound )
	self:ShootEffects( self )
	if ( !SERVER ) then return end
	local eAng = self.Owner:EyeAngles()
	local Forward = self.Owner:EyeAngles():Forward()
	local shootPos = self.Owner:GetShootPos() + eAng:Forward() * 10 + eAng:Right()*25 - eAng:Up() * 10
		local TVTypes = {
            "models/props_c17/tv_monitor01.mdl",
             "models/props/de_inferno/tv_monitor01.mdl",
            "models/props_spytech/tv001.mdl"
    }
	local ent = ents.Create( "prop_physics" )
	if ( IsValid( ent ) ) then
	ent:SetPos(shootPos + Vector(math.Rand(1,-1),math.Rand(1,-1),math.Rand(1,-1)))
	ent:SetAngles( self.Owner:EyeAngles() )
	ent:SetModel(table.Random(TVTypes))
	ent:Spawn()
	ent:SetOwner(self.Owner)
	ent:SetVelocity( Forward * 1500 + Vector(0,0,15))
		local phys = ent:GetPhysicsObject()
 
	if !(phys && IsValid(phys)) then ent:Remove() return end
 
	ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	phys:ApplyForceCenter(self.Owner:GetAimVector() * 90000 )
	ent:SetModel(table.Random(TVTypes))
	timer.Simple(0.01, function() ent:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE) end)
	timer.Simple(4, function() ent:Remove() end)
end
end

function SWEP:SecondaryAttack()
local function BurstAttack()
	
	self:SetNextPrimaryFire( CurTime() + 0.1 )

	//self:EmitSound( ShootSound )
	self:ShootEffects( self )
	if ( !SERVER ) then return end
	local eAng = self.Owner:EyeAngles()
	local Forward = self.Owner:EyeAngles():Forward()
	local shootPos = self.Owner:GetShootPos() + eAng:Forward() * 10 + eAng:Right()*25 - eAng:Up() * 10
		local TVTypes = {
            "models/props_c17/tv_monitor01.mdl",
            "models/props/de_inferno/tv_monitor01.mdl",
            "models/props_spytech/tv001.mdl"
    }
	local ent = ents.Create( "prop_physics" )
	if ( IsValid( ent ) ) then
	ent:SetPos(shootPos + Vector(math.Rand(1,-1),math.Rand(1,-1),math.Rand(1,-1)))
	ent:SetAngles( self.Owner:EyeAngles() )
	ent:SetModel(table.Random(TVTypes))
	ent:Spawn()
	ent:SetOwner(self.Owner)
	ent:SetVelocity( Forward * 1500 + Vector(0,0,15))
		local phys = ent:GetPhysicsObject()
 
	if !(phys && IsValid(phys)) then ent:Remove() return end
 
	ent:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
	phys:ApplyForceCenter(self.Owner:GetAimVector() * 90000 )
	ent:SetModel(table.Random(TVTypes))
	timer.Simple(0.01, function() ent:SetCollisionGroup(COLLISION_GROUP_INTERACTIVE) end)
		timer.Simple(4, function() ent:Remove() end)
end
end
	-- TODO: Implement burst fire.
		self:PrimaryAttack()
		timer.Create("FireBurstShot1",0.08,1, BurstAttack)
		timer.Create("FireBurstShot2",0.16,1, BurstAttack)
		self:EmitSound( Sound("weapons/smg1/44k/smg2_fireburst1.wav") )
		self.Weapon:SetNextSecondaryFire( CurTime() + 0.5 )
		
end

function SWEP:ShouldDropOnDie()

	return false

end

function SWEP:GetNPCRestTimes()

	-- Handles the time between bursts
	-- Min rest time in seconds, max rest time in seconds

	return 0.3, 0.6

end

function SWEP:GetNPCBurstSettings()

	-- Handles the burst settings
	-- Minimum amount of shots, maximum amount of shots, and the delay between each shot
	-- The amount of shots can end up lower than specificed

	return 1, 6, 0.1

end

function SWEP:GetNPCBulletSpread( proficiency )

	-- Handles the bullet spread based on the given proficiency
	-- return value is in degrees

	return 1

end
